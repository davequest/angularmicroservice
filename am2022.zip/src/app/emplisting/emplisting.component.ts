import { Component, OnInit } from '@angular/core';
import { Observable, of } from 'rxjs';
import { EmployeeService } from '../service/employee.service';
import { DestService } from '../service/dest.service';

@Component({
  selector: 'app-emplisting',
  templateUrl: './emplisting.component.html',
  styleUrls: ['./emplisting.component.css']
})
export class EmplistingComponent implements OnInit {
  employeedata: any;
  employees: any;
  contact: any;
  users: any;
  constructor(private service: EmployeeService,
    private serviceDest: DestService,
    
    ) {
    
  }

  ngOnInit(): void {
    this.LoadAll();
  }

  LoadAll(): void {
    this.service.LoadAllEmployee().subscribe((result:any) => {
      this.employeedata = result;
      //console.log(this.employeedata);
      //this.employees = {designation: null };
      //console.log(this.employees);

      this.employeedata?.forEach((element:any, indexElement: number) => {
        let x=element.designationId;
       //console.log(element.designationId);

       /*this.serviceDest.GetByCode(x).subscribe((result2:any) => {
       // console.log("result2->",result2.description);

        //console.log(this.employeedata[0].description);
        
      });
      */
      });
      
    

    });
  }
  delete(code: any) {
    if (confirm("Do you want remove?")) {
      this.service.RemoveEmployeebycode(code).subscribe(result => {
        this.LoadAll();
      });
    }
  }
}
