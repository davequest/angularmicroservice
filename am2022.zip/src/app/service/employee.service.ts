import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
 

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
apiurl_des='http://localhost:3001/designation'
apiurl='http://localhost:3000/employee'
  constructor(private http:HttpClient) { 

  }
  LoadDesignation(){
    return this.http.get(this.apiurl_des);
  }

  LoadAllEmployee():Observable<any>{  
    return this.http.get(this.apiurl);
  }
  Employeebycode(code:any){
    return this.http.get(this.apiurl+'/'+code);
  }
  RemoveEmployeebycode(code:any){
    return this.http.delete(this.apiurl+'/'+code);
  }
  SaveEmployee1(id:any,inputdata:any): Observable<any>{
    return this.http.put(this.apiurl+'/'+id,inputdata);
  }

}
